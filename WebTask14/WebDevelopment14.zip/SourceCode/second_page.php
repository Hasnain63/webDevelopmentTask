<!DOCTYPE html>
<html>
<head>
	<title>User Submission Form via AJAX</title>
</head>
<body>
	<?php 
	// write code to perform form submission and send response back to AJAX request


	?>
	
	
</body>
</html>